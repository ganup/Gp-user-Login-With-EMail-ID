<?php
/*
Plugin Name: Gp user Login With EMail-ID
Plugin URI: 
Version: 1.0
Author: Ganesh Paygude
Description: Allow user to login with their Email ID.
*/

/* Setup the plugin. */
add_action( 'plugins_loaded', 'gpel_plugin_setup' );

/* Register plugin activation hook. */
register_activation_hook( __FILE__, 'gpel_plugin_activation' );

/* Register plugin activation hook. */
register_deactivation_hook( __FILE__, 'gpel_plugin_deactivation' );
/**
 * Do things on plugin activation.
 *
 */
function gpel_plugin_activation() {
	/* Flush permalinks. */
    flush_rewrite_rules();
}
/**
 * Flush permalinks on plugin deactivation.
 */
function gpel_plugin_deactivation() {
    flush_rewrite_rules();
}
function gpel_plugin_setup() {
// create custom plugin settings menu
/* Get the plugin directory URI. */
	define( 'GP_EMAIL_LOGIN_PLUGIN_URI', trailingslashit( plugin_dir_url( __FILE__ ) ) );
	add_action('admin_menu', 'gpel_plugin_create_menu');

}

function gpel_plugin_create_menu() {

	//create new top-level menu
	add_menu_page('Login with Email ID', 'Login with Email-ID  Settings', 'administrator', __FILE__, 'gpel_plugin_settings_page' , plugins_url('/images/email-icon.png', __FILE__) );

	//call register settings function
	add_action( 'admin_init', 'gpel_register_plugin_settings' );
}


function gpel_register_plugin_settings() {
	//register our settings	
	register_setting( 'gpel-plugin-settings-group', 'gpel_allow_email_login' );
}

function gpel_plugin_settings_page() {
?>
<div class="wrap">
<h2>Login With Email ID:</h2>

<form method="post" action="options.php">
    <?php settings_fields( 'gpel-plugin-settings-group' ); ?>
    <?php do_settings_sections( 'gpel-plugin-settings-group' ); ?>
    <table class="form-table">
	<?php 	$gpel_allow_email_login = get_option( 'gpel_allow_email_login' );	?>	
	
	<tr valign="top">
        <th scope="row">Allow Login with Email ID:</th>
        <td><input type='checkbox' id='gpel_allow_email_login' name='gpel_allow_email_login' value='1' <?php echo checked( $gpel_allow_email_login, 1, false );?> /></td>
        </tr>
			
    </table>
    
    <?php submit_button(); ?>

</form>
</div>
<?php }
$gpel_allow_email_login = get_option('gpel_allow_email_login');

if(checked( $gpel_allow_email_login, 1, false )){	

	function gpel_login_with_email_address($username) {
		$user = get_user_by_email($username);
		if(!empty($user->user_login))
			$username = $user->user_login;
		return $username;
	}
	add_action('wp_authenticate','gpel_login_with_email_address');

	function gpel_login_function() {
		add_filter( 'gettext', 'gpel_username_label_change', 20, 3 );
		function gpel_username_label_change( $translated_text, $text, $domain ) 
		{
			if ($text === 'Username') 
			{
				$translated_text = 'Username or Email';
			}
			return $translated_text;
		}
	}
	add_action( 'login_head', 'gpel_login_function' );
	
}
 ?>